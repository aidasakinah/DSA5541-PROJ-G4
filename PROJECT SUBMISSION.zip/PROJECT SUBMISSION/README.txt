For ADMIN:
user: admin
password: admin123

For USER:
user: user
password: 12345

To use the system, please run it in either vscode or dec c++. The user must first login to the sytem by using the details listed above.
